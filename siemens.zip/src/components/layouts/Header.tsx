"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useEffect } from "react";
import { FiMenu, FiX, FiUser } from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/components/providers/AuthProvider";
import HeaderLikeBtn from "../features/HeaderLikeBtn";
import HeaderSearchbar from "../features/HeaderSearchbar";
import { useScrollLock, useToggle } from "iso-hooks";

export default function Header() {
  const pathname = usePathname();
  const { token } = useAuth();

  // State management
  const [isMobileOpen, setIsMobileOpen] = useToggle(false);
  const [scrolled, setScrolled] = useToggle(false);

  // Handle Scroll Effect
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const { lock, unlock } = useScrollLock();

  useEffect(() => {
    isMobileOpen ? lock() : unlock();
  }, [isMobileOpen]);

  const links = [
    { name: "خانه", href: "/" },
    { name: "فروشگاه", href: "/shop" },
    { name: "مقالات", href: "/blog" },
    { name: "درباره ما", href: "/about-us" },
    { name: "تماس با ما", href: "/contact-us" },
  ];

  return (
    <>
      {/* --- Main Header --- */}
      <header
        className={`sticky top-0 left-0 w-full z-50 transition-all duration-300 border-b ${
          scrolled
            ? "bg-white/90 backdrop-blur-md border-slate-200 py-3 shadow-sm"
            : "bg-white border-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 flex items-center justify-between gap-2 sm:gap-4">
          {/* 1. Logo Section */}
          <Link href="/" className="flex items-center gap-3 shrink-0 group">
            <div className="relative w-10 h-10 overflow-hidden rounded-lg">
              <Image
                src="/images/logo.jpg"
                alt="Siemens Plus"
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-500"
              />
            </div>
            <div className="hidden sm:flex flex-col font-vazir">
              <span className="text-xl font-bold text-slate-900 leading-none">
                زیمِنس <span className="text-primary">پلاس</span>
              </span>
             
            </div>
          </Link>

          {/* 2. Desktop Navigation (Centered) */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-50/50 p-1 rounded-full border border-slate-200/50 px-2">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  pathname === link.href
                    ? "bg-white text-primary shadow-sm border border-slate-100"
                    : "text-slate-600 hover:text-primary hover:bg-slate-100/50"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* 3. Right Actions (Search + Auth + Cart) */}
          <div className="flex items-center gap-1.5 sm:gap-2 md:gap-3">
            {/* Compact Search Bar */}
            <HeaderSearchbar />

            <div className="h-6 w-px bg-slate-200 hidden sm:block"></div>

            {/* Likes Button */}
            <HeaderLikeBtn />

            {/* Login / Dashboard */}
            {token ? (
              <Link
                href="/dashboard"
                className="hidden sm:flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary/90 text-white rounded-full text-sm font-medium transition shadow-sm shadow-primary/20"
              >
                <FiUser />
                <span>داشبورد</span>
              </Link>
            ) : (
              <Link
                href="/login"
                className="hidden sm:flex items-center gap-2 px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-full text-sm font-medium transition"
              >
                ورود
              </Link>
            )}

            {/* Mobile Menu Trigger */}
            <button
              onClick={() => setIsMobileOpen(true)}
              className="lg:hidden p-2.5 sm:p-3 text-slate-800 bg-slate-100 rounded-lg active:scale-95 transition min-w-[44px] min-h-[44px] flex items-center justify-center touch-manipulation"
              aria-label="باز کردن منو"
            >
              <FiMenu size={24} />
            </button>
          </div>
        </div>
      </header>

      {/* --- Mobile Drawer (Fixed Logic) --- */}
      <AnimatePresence>
        {isMobileOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileOpen(false)}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60]"
            />

            {/* Drawer Panel */}
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 w-[85vw] max-w-[320px] h-screen bg-white z-[70] shadow-2xl overflow-y-auto"
            >
              {/* Drawer Header */}
              <div className="p-5 flex items-center justify-between border-b border-slate-100">
                <div className="font-bold text-lg text-slate-800">
                  منوی دسترسی
                </div>
                <button
                  onClick={() => setIsMobileOpen(false)}
                  className="p-2.5 hover:bg-red-50 text-slate-500 hover:text-red-500 rounded-full transition min-w-[44px] min-h-[44px] flex items-center justify-center touch-manipulation"
                  aria-label="بستن منو"
                >
                  <FiX size={24} />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="p-4 space-y-6">
                {/* Mobile Search */}
                <HeaderSearchbar />

                {/* Mobile Links */}
                <div className="flex flex-col space-y-1">
                  {links.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setIsMobileOpen(false)}
                      className={`px-4 py-3.5 min-h-[48px] flex items-center rounded-xl text-base font-medium transition touch-manipulation ${
                        pathname === link.href
                          ? "bg-primary/10 text-primary"
                          : "text-slate-600 hover:bg-slate-50 active:bg-slate-100"
                      }`}
                    >
                      {link.name}
                    </Link>
                  ))}
                </div>

                {/* Mobile Auth Buttons */}
                <div className="pt-6 border-t border-slate-100">
                  {!token ? (
                    <div className="grid grid-cols-2 gap-3">
                      <Link
                        href="/login"
                        onClick={() => setIsMobileOpen(false)}
                        className="flex justify-center items-center py-3.5 min-h-[48px] border border-slate-200 rounded-xl text-base font-medium text-slate-700 hover:bg-slate-50 active:bg-slate-100 transition touch-manipulation"
                      >
                        ورود
                      </Link>
                      <Link
                        href="/register"
                        onClick={() => setIsMobileOpen(false)}
                        className="flex justify-center items-center py-3.5 min-h-[48px] bg-slate-900 text-white rounded-xl text-base font-medium hover:bg-slate-800 active:bg-slate-700 transition touch-manipulation"
                      >
                        ثبت نام
                      </Link>
                    </div>
                  ) : (
                    <Link
                      href="/dashboard"
                      onClick={() => setIsMobileOpen(false)}
                      className="flex items-center justify-center gap-2 w-full py-3.5 min-h-[48px] bg-primary text-white rounded-xl text-base font-medium hover:bg-primary/90 active:bg-primary/80 transition touch-manipulation"
                    >
                      <FiUser /> ورود به داشبورد
                    </Link>
                  )}
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
